package jGame.model.game;

public class GameSceneLoader {

}
