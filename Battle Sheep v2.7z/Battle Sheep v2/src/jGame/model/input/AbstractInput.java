package jGame.model.input;

public interface AbstractInput {
	public void pollInput();
}
