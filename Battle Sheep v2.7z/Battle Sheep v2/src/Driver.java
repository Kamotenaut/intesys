import battlesheep.view.BattleSheepGame;

public class Driver {

	public static void main(String[] args) {
		new BattleSheepGame("Battle Sheep v2", 740, 540, 30).start();
	}

}
